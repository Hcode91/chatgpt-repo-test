# LocalPaint: on-device Stable Diffusion 1.5 inpainting for Android

**Prototype / alpha.** Native image generation is wired up via `stable-diffusion.cpp`, but this project has **not yet been compiled or tested on a physical device**. This is not a prebuilt APK. It may need compatibility fixes as the upstream API changes.

## What it does

- Import a local full Stable Diffusion 1.5 **inpainting** single-file `.safetensors` checkpoint (not supplied).
- Pick a photo with Android's system file picker. Input is downscaled to a maximum of 512 pixels along the long edge and rounded to dimensions divisible by 64.
- Paint a mask on the picture. Painted white mask regions are the areas to regenerate.
- Undo/clear strokes, adjust brush diameter, provide prompt and negative prompt.
- Change steps (5-34), denoising strength (0.10-1.0). Currently uses CFG=7.0 and randomized seed.
- Perform local inference through JNI and `stable-diffusion.cpp` on a native background thread.
- Preview the output and save a PNG to `Pictures/LocalPaint` or use the result for another pass.
- Offline inference: no internet permission, no image transfer or telemetry in app code.

## Build on GitHub Actions (recommended)

1. Create an **empty GitHub repository** and upload all source files from this ZIP while preserving paths, including `.github/workflows/android.yml`.
2. Go to the repo's **Actions** tab and run **Android APK** using `Run workflow` or push a commit.
3. Open the completed workflow and download the `LocalPaint-debug-apk` artifact, then extract `app-debug.apk`.
4. Sideload on Android (Settings > Allow install from this source when prompted).
5. Import your legally obtained compatible **full SD 1.5 inpainting `.safetensors`** checkpoint. Model stays in `getFilesDir()/models/sd15.safetensors`.
6. Choose image, paint the target area, enter prompt, press Generate locally.

The CI clones stable-diffusion.cpp at build time with its submodules. For a reproducible release, **pin and test an upstream engine commit** before shipping. A normal build requires a network connection on the GitHub runner to fetch Android build dependencies. Your Android phone is offline while generating.

## Local build (Android Studio)

Requirements: Android 10 or newer, Android SDK 35, NDK 27.2.12479018, CMake 3.22.1, Java 17, Gradle 8.9.

```
bash scripts/fetch-engine.sh
gradle :app:assembleDebug
```

## Performance notes

- Initial build is **CPU-only**. The Snapdragon 8 Gen 2 has NPU hardware, but this build does not integrate Qualcomm's QNN runtime or precompiled NPU model formats. Expect slow generation and significant battery drain and heat.
- SD1.5 generally targets ~512px images, but the 8 GB system RAM limit can still cause OOM kills. Start with a lower-resolution input or quantized **supported** model architecture after validating engine compatibility.
- Importing a checkpoint **copies** the file into private storage. Allow space for both the source and copied file. A complete `safetensors` model may require several GB.
- Checkpoint file extensions alone do not guarantee compatibility. A standalone `.gguf` UNet often also requires separate text encoder and VAE, which the current UI does not expose. Use a single-file complete `.safetensors` SD 1.5 inpainting checkpoint.
- Inpainting-specialized 9-channel models and ordinary 4-channel checkpoints behave differently. The engine and chosen model must actually support masked image generation.
- Photo import currently does not apply EXIF rotation. Some camera JPEGs may appear sideways. 512px resizing changes original resolution.

## Troubleshooting

- **Build fails in engine CMake/C++**: upstream was updated after this prototype. Pin a compatible stable-diffusion.cpp commit and make the JNI bridge agree with the bundled public header.
- **Crash at model load**: check `adb logcat`, RAM, checkpoint architecture and available internal storage.
- **App freezes or heats up**: first load plus sampling can be slow. Keep it foreground; background execution isn't yet supported.
- **OpenCL / GPU / QNN**: not included in this starter version. GPU acceleration needs a separate backend integration and real-device validation.
- **Security**: inspect third-party model licenses and model source; do not import untrusted model formats. App uses only the local file picker and the MediaStore PNG output API.

## Attribution

Uses [`leejet/stable-diffusion.cpp`](https://github.com/leejet/stable-diffusion.cpp) under its own licence and subproject licences. Models are not included and their terms vary.
