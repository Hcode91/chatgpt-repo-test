package com.localpaint.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQUEST_IMAGE = 101;
    private static final int REQUEST_MODEL = 102;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private MaskEditor editor;
    private EditText promptInput;
    private EditText negativeInput;
    private TextView statusText;
    private TextView strengthText;
    private TextView stepsText;
    private TextView brushText;
    private ImageView outputPreview;
    private ProgressBar progress;
    private Button generateButton;
    private Button saveButton;
    private SeekBar strengthSeek;
    private SeekBar stepsSeek;
    private SeekBar brushSeek;
    private Bitmap generated;
    private String modelPath;
    private boolean busy;

    private int bg = Color.rgb(16, 18, 28);
    private int card = Color.rgb(29, 32, 47);
    private int accent = Color.rgb(165, 130, 255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        File saved = new File(getFilesDir(), "models/sd15.safetensors");
        if (saved.exists() && saved.length() > 100_000_000L) modelPath = saved.getAbsolutePath();
        createUi();
        setStatus(modelPath == null ? "Import an SD 1.5 inpainting checkpoint to begin."
                                    : "Model available offline: " + (saved.length() / (1024 * 1024)) + " MB");
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + .5f); }

    private LinearLayout vertical() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private TextView label(String value, int sp, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setPadding(0, dp(7), 0, dp(5));
        return view;
    }

    private Button button(String name, LinearLayout parent, View.OnClickListener click) {
        Button btn = new Button(this);
        btn.setText(name);
        btn.setAllCaps(false);
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(card));
        parent.addView(btn, new LinearLayout.LayoutParams(-1, dp(53)));
        btn.setOnClickListener(click);
        return btn;
    }

    private EditText edit(String hint, int lines) {
        EditText view = new EditText(this);
        view.setHint(hint);
        view.setTextSize(15);
        view.setTextColor(Color.WHITE);
        view.setHintTextColor(Color.LTGRAY);
        view.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        view.setSingleLine(lines == 1);
        if (lines > 1) view.setMinLines(lines);
        return view;
    }

    private void createUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = vertical();
        root.setPadding(dp(18), dp(18), dp(18), dp(40));
        scroll.addView(root);
        setContentView(scroll);

        root.addView(label("LOCALPAINT", 25, Color.WHITE));
        root.addView(label("Offline Stable Diffusion 1.5 inpainting", 13, accent));
        root.addView(label("Nothing you edit is uploaded. The model runs on your phone.", 12, Color.LTGRAY));
        root.addView(label("1 · MODEL & PHOTO", 18, Color.WHITE));
        button("Import SD1.5 inpainting checkpoint (.safetensors)", root, v -> pick(REQUEST_MODEL, "*/*"));
        button("Choose photo", root, v -> pick(REQUEST_IMAGE, "image/*"));

        root.addView(label("2 · BRUSH THE AREA TO REPLACE", 18, Color.WHITE));
        editor = new MaskEditor(this);
        editor.setBackgroundColor(card);
        LinearLayout.LayoutParams canvasLp = new LinearLayout.LayoutParams(-1, dp(320));
        canvasLp.topMargin = dp(8);
        root.addView(editor, canvasLp);
        brushText = label("Brush size: 40 px", 13, Color.LTGRAY);
        root.addView(brushText);
        brushSeek = new SeekBar(this);
        brushSeek.setMax(95);
        brushSeek.setProgress(32);
        root.addView(brushSeek);
        brushSeek.setOnSeekBarChangeListener(new SimpleSeek(value -> {
            int brush = value + 8;
            editor.setBrushSize(brush);
            brushText.setText("Brush size: " + brush + " px");
        }));
        editor.setBrushSize(40);
        button("Undo last stroke", root, v -> editor.undo());
        button("Clear painted mask", root, v -> editor.clearMask());

        root.addView(label("3 · DESCRIBE THE NEW DETAILS", 18, Color.WHITE));
        promptInput = edit("e.g. a bouquet of red flowers on the table, realistic", 2);
        root.addView(promptInput);
        root.addView(label("Negative prompt (optional)", 13, Color.LTGRAY));
        negativeInput = edit("blurry, distorted, low quality", 1);
        negativeInput.setText("blurry, low quality, deformed");
        root.addView(negativeInput);
        strengthText = label("Denoising strength: 0.75", 13, Color.LTGRAY);
        root.addView(strengthText);
        strengthSeek = new SeekBar(this);
        strengthSeek.setMax(90);
        strengthSeek.setProgress(65);
        root.addView(strengthSeek);
        strengthSeek.setOnSeekBarChangeListener(new SimpleSeek(value ->
            strengthText.setText(String.format(java.util.Locale.US, "Denoising strength: %.2f", (value + 10) / 100f))));
        stepsText = label("Steps: 15 (more steps take longer)", 13, Color.LTGRAY);
        root.addView(stepsText);
        stepsSeek = new SeekBar(this);
        stepsSeek.setMax(29);
        stepsSeek.setProgress(10);
        root.addView(stepsSeek);
        stepsSeek.setOnSeekBarChangeListener(new SimpleSeek(value ->
            stepsText.setText("Steps: " + (value + 5) + " (more steps take longer)")));

        generateButton = button("✦ Generate locally", root, v -> generate());
        generateButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(34)));
        statusText = label("", 13, Color.LTGRAY);
        root.addView(statusText);
        root.addView(label("4 · RESULT", 18, Color.WHITE));
        outputPreview = new ImageView(this);
        outputPreview.setBackgroundColor(card);
        outputPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(outputPreview, new LinearLayout.LayoutParams(-1, dp(270)));
        saveButton = button("Save PNG to Pictures/LocalPaint", root, v -> saveImage());
        saveButton.setEnabled(false);
        button("Edit generated image again", root, v -> {
            if (generated != null && !busy) {
                editor.setImage(generated);
                generated = null;
                saveButton.setEnabled(false);
                outputPreview.setImageDrawable(null);
                setStatus("Result copied to canvas. Paint a new mask to continue.");
            }
        });
        root.addView(label("Recommended: 512px input, 10-20 steps. The initial build uses CPU, not Snapdragon NPU acceleration.", 12, Color.GRAY));
    }

    private void pick(int requestCode, String mime) {
        if (busy) return;
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType(mime);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(intent, requestCode);
    }

    @Override protected void onActivityResult(int request, int resultCode, Intent data) {
        super.onActivityResult(request, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == REQUEST_MODEL) importModel(uri);
        else if (request == REQUEST_IMAGE) importImage(uri);
    }

    private void importModel(Uri uri) {
        setBusy(true);
        setStatus("Copying checkpoint into private app storage… keep the app open.");
        executor.execute(() -> {
            File folder = new File(getFilesDir(), "models");
            File staging = new File(folder, "sd15.tmp");
            File target = new File(folder, "sd15.safetensors");
            try {
                if (!folder.exists() && !folder.mkdirs()) throw new Exception("Cannot create model directory");
                long bytes = 0;
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = new FileOutputStream(staging)) {
                    if (in == null) throw new Exception("Unable to open checkpoint");
                    byte[] buf = new byte[1024 * 1024];
                    int n;
                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n);
                        bytes += n;
                    }
                }
                if (bytes < 100_000_000L) throw new Exception("File is too small for a full SD 1.5 checkpoint");
                // Drop the old mapped context before replacing its backing file.
                if (modelPath != null) NativeEngine.release();
                if (target.exists() && !target.delete()) throw new Exception("Could not replace previous checkpoint");
                if (!staging.renameTo(target)) throw new Exception("Could not move imported checkpoint");
                modelPath = target.getAbsolutePath();
                final long mb = bytes / (1024 * 1024);
                runOnUiThread(() -> setStatus("Model imported: " + mb + " MB. Ready for offline use."));
            } catch (Throwable e) {
                staging.delete();
                runOnUiThread(() -> setStatus("Model import failed: " + shortError(e)));
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        });
    }

    private void importImage(Uri uri) {
        setBusy(true);
        executor.execute(() -> {
            try {
                BitmapFactory.Options info = new BitmapFactory.Options();
                info.inJustDecodeBounds = true;
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(stream, null, info);
                }
                if (info.outWidth < 64 || info.outHeight < 64) throw new Exception("Image is too small or unreadable");
                BitmapFactory.Options options = new BitmapFactory.Options();
                int sample = 1;
                while (info.outWidth / sample > 1536 || info.outHeight / sample > 1536) sample *= 2;
                options.inSampleSize = sample;
                Bitmap decoded;
                try (InputStream stream = getContentResolver().openInputStream(uri)) {
                    decoded = BitmapFactory.decodeStream(stream, null, options);
                }
                if (decoded == null) throw new Exception("Unsupported image format");
                // Choose compact dimensions in multiples of 64 to fit the SD 1.5 latent grid.
                float scale = Math.min(512f / decoded.getWidth(), 512f / decoded.getHeight());
                int width = Math.max(64, Math.round(decoded.getWidth() * scale / 64f) * 64);
                int height = Math.max(64, Math.round(decoded.getHeight() * scale / 64f) * 64);
                width = Math.min(512, width);
                height = Math.min(512, height);
                Bitmap resized = Bitmap.createScaledBitmap(decoded, width, height, true).copy(Bitmap.Config.ARGB_8888, false);
                decoded.recycle();
                runOnUiThread(() -> {
                    editor.setImage(resized);
                    generated = null;
                    outputPreview.setImageDrawable(null);
                    saveButton.setEnabled(false);
                    setStatus("Photo ready (" + width + "×" + height + "). Paint the region to change.");
                });
            } catch (Throwable e) {
                runOnUiThread(() -> setStatus("Image import failed: " + shortError(e)));
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        });
    }

    private void generate() {
        if (busy) return;
        Bitmap image = editor.getImage();
        if (modelPath == null) { setStatus("Choose an SD 1.5 inpainting model first."); return; }
        if (image == null) { setStatus("Choose a photo first."); return; }
        String prompt = promptInput.getText().toString().trim();
        if (prompt.isEmpty()) { setStatus("Describe what should appear in the painted area."); return; }
        byte[] mask = editor.getMaskBytes();
        boolean hasMask = false;
        for (byte b : mask) { if (b != 0) { hasMask = true; break; } }
        if (!hasMask) { setStatus("Paint over the area you want regenerated first."); return; }
        final int width = image.getWidth();
        final int height = image.getHeight();
        int[] pixels = new int[width * height];
        image.getPixels(pixels, 0, width, 0, 0, width, height);
        int steps = stepsSeek.getProgress() + 5;
        float strength = (strengthSeek.getProgress() + 10) / 100f;
        String negative = negativeInput.getText().toString();
        String model = modelPath;
        setBusy(true);
        setStatus("Loading model / generating on-device. CPU inference may take several minutes; keep the screen active.");
        executor.execute(() -> {
            try {
                long seed = System.currentTimeMillis() & 0x7fffffff;
                int[] output = NativeEngine.inpaint(model, pixels, mask, width, height,
                        prompt, negative, steps, strength, seed, 7.0f);
                if (output == null || output.length != width * height) throw new Exception("No output pixels returned");
                Bitmap bitmap = Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888);
                runOnUiThread(() -> {
                    generated = bitmap;
                    outputPreview.setImageBitmap(bitmap);
                    saveButton.setEnabled(true);
                    setStatus("Finished on-device. Save the PNG or edit it again.");
                });
            } catch (Throwable e) {
                runOnUiThread(() -> setStatus("Generation failed: " + shortError(e)));
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        });
    }

    private String shortError(Throwable e) {
        String message = e.getMessage();
        if (message == null || message.trim().isEmpty()) return e.getClass().getSimpleName();
        return message.length() > 190 ? message.substring(0, 190) : message;
    }

    private void saveImage() {
        if (generated == null || busy) return;
        Bitmap snapshot = generated;
        setBusy(true);
        executor.execute(() -> {
            Uri inserted = null;
            try {
                String name = "LocalPaint_" + System.currentTimeMillis() + ".png";
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/LocalPaint");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                }
                inserted = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (inserted == null) throw new Exception("Could not create MediaStore entry");
                try (OutputStream out = getContentResolver().openOutputStream(inserted)) {
                    if (out == null || !snapshot.compress(Bitmap.CompressFormat.PNG, 100, out)) {
                        throw new Exception("PNG writing failed");
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(inserted, done, null, null);
                }
                runOnUiThread(() -> setStatus("Saved to Pictures/LocalPaint."));
            } catch (Throwable e) {
                if (inserted != null) getContentResolver().delete(inserted, null, null);
                runOnUiThread(() -> setStatus("Save failed: " + shortError(e)));
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        });
    }

    private void setStatus(String message) {
        if (statusText != null) statusText.setText(message);
    }

    private void setBusy(boolean value) {
        busy = value;
        if (progress != null) progress.setVisibility(value ? View.VISIBLE : View.GONE);
        if (generateButton != null) generateButton.setEnabled(!value);
        if (saveButton != null) saveButton.setEnabled(!value && generated != null);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
        // Native model is kept only for the lifespan of this process; OS reclaims it on exit.
    }

    interface ProgressChanged { void update(int progress); }
    static final class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        final ProgressChanged action;
        SimpleSeek(ProgressChanged action) { this.action = action; }
        @Override public void onProgressChanged(SeekBar bar, int progress, boolean byUser) { action.update(progress); }
        @Override public void onStartTrackingTouch(SeekBar bar) {}
        @Override public void onStopTrackingTouch(SeekBar bar) {}
    }
}
