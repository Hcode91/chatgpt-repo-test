package com.localpaint.app;

public final class NativeEngine {
    static { System.loadLibrary("localpaint"); }
    private NativeEngine() {}

    public static native int[] inpaint(String modelPath, int[] argb, byte[] mask,
                                      int width, int height, String prompt,
                                      String negativePrompt, int steps,
                                      float strength, long seed, float cfg);
    public static native void release();
}
