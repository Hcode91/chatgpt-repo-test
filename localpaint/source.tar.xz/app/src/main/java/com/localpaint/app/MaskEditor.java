package com.localpaint.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayDeque;

public final class MaskEditor extends View {
    private Bitmap image;
    private Bitmap paintedMask;
    private Canvas maskCanvas;
    private final Paint brush = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint imagePaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint overlay = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF bounds = new RectF();
    private final ArrayDeque<Bitmap> undoStack = new ArrayDeque<>();
    private float lastX, lastY;
    private int brushSize = 40;

    public MaskEditor(Context context) {
        super(context);
        brush.setColor(Color.WHITE);
        brush.setStyle(Paint.Style.STROKE);
        brush.setStrokeCap(Paint.Cap.ROUND);
        brush.setStrokeJoin(Paint.Join.ROUND);
        brush.setStrokeWidth(brushSize);
        overlay.setColorFilter(new PorterDuffColorFilter(Color.rgb(160, 99, 255), PorterDuff.Mode.SRC_IN));
        overlay.setAlpha(145);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setImage(Bitmap newImage) {
        image = newImage;
        clearMask();
        invalidate();
    }

    public Bitmap getImage() { return image; }

    public void setBrushSize(int size) {
        brushSize = Math.max(8, Math.min(110, size));
        brush.setStrokeWidth(brushSize);
    }

    public void clearMask() {
        undoStack.clear();
        if (image == null) return;
        paintedMask = Bitmap.createBitmap(image.getWidth(), image.getHeight(), Bitmap.Config.ARGB_8888);
        maskCanvas = new Canvas(paintedMask);
        invalidate();
    }

    public void undo() {
        if (!undoStack.isEmpty()) {
            paintedMask = undoStack.pop();
            maskCanvas = new Canvas(paintedMask);
            invalidate();
        }
    }

    public byte[] getMaskBytes() {
        if (paintedMask == null) return new byte[0];
        int count = paintedMask.getWidth() * paintedMask.getHeight();
        int[] pixels = new int[count];
        paintedMask.getPixels(pixels, 0, paintedMask.getWidth(), 0, 0,
                paintedMask.getWidth(), paintedMask.getHeight());
        byte[] mask = new byte[count];
        for (int i = 0; i < count; ++i) mask[i] = (byte) (pixels[i] >>> 24);
        return mask;
    }

    private void updateBounds() {
        if (image == null) return;
        float scale = Math.min((float) getWidth() / image.getWidth(),
                               (float) getHeight() / image.getHeight());
        float w = image.getWidth() * scale, h = image.getHeight() * scale;
        float left = (getWidth() - w) / 2f, top = (getHeight() - h) / 2f;
        bounds.set(left, top, left + w, top + h);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (image == null) {
            Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
            text.setColor(Color.LTGRAY);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(33 * getResources().getDisplayMetrics().scaledDensity / 2f);
            canvas.drawText("Choose a photo to begin", getWidth() / 2f, getHeight() / 2f, text);
            return;
        }
        updateBounds();
        canvas.drawBitmap(image, null, bounds, imagePaint);
        if (paintedMask != null) canvas.drawBitmap(paintedMask, null, bounds, overlay);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (image == null || maskCanvas == null) return false;
        updateBounds();
        float x = (event.getX() - bounds.left) * image.getWidth() / bounds.width();
        float y = (event.getY() - bounds.top) * image.getHeight() / bounds.height();
        x = Math.max(0, Math.min(image.getWidth() - 1, x));
        y = Math.max(0, Math.min(image.getHeight() - 1, y));
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!bounds.contains(event.getX(), event.getY())) return false;
                getParent().requestDisallowInterceptTouchEvent(true);
                undoStack.push(paintedMask.copy(Bitmap.Config.ARGB_8888, true));
                if (undoStack.size() > 8) undoStack.removeLast().recycle();
                lastX = x; lastY = y;
                maskCanvas.drawPoint(x, y, brush);
                Paint dab = new Paint(Paint.ANTI_ALIAS_FLAG);
                dab.setColor(Color.WHITE);
                maskCanvas.drawCircle(x, y, brushSize / 2f, dab);
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                maskCanvas.drawLine(lastX, lastY, x, y, brush);
                lastX = x; lastY = y;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
        }
        return false;
    }
}
