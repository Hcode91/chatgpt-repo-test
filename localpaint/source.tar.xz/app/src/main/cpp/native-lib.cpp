#include <jni.h>
#include <android/log.h>
#include <stable-diffusion.h>
#include <algorithm>
#include <cstdint>
#include <mutex>
#include <string>
#include <vector>

namespace {
std::mutex engineMutex;
sd_ctx_t* cachedCtx = nullptr;
std::string cachedModel;

void fail(JNIEnv* env, const char* message) {
    jclass klass = env->FindClass("java/lang/IllegalStateException");
    if (klass) env->ThrowNew(klass, message);
}

std::string jstringToString(JNIEnv* env, jstring input) {
    if (!input) return "";
    const char* chars = env->GetStringUTFChars(input, nullptr);
    if (!chars) return "";
    std::string value(chars);
    env->ReleaseStringUTFChars(input, chars);
    return value;
}

void releaseCachedContext() {
    if (cachedCtx) {
        free_sd_ctx(cachedCtx);
        cachedCtx = nullptr;
        cachedModel.clear();
    }
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_localpaint_app_NativeEngine_release(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> lock(engineMutex);
    releaseCachedContext();
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_localpaint_app_NativeEngine_inpaint(JNIEnv* env, jclass,
                                             jstring jModelPath,
                                             jintArray jArgb,
                                             jbyteArray jMask,
                                             jint width,
                                             jint height,
                                             jstring jPrompt,
                                             jstring jNegative,
                                             jint steps,
                                             jfloat strength,
                                             jlong seed,
                                             jfloat cfg) {
    std::lock_guard<std::mutex> lock(engineMutex);
    if (width < 64 || height < 64 || width > 1024 || height > 1024 ||
        width % 64 || height % 64) {
        fail(env, "Image dimensions must be multiples of 64, between 64 and 1024.");
        return nullptr;
    }
    const jsize count = width * height;
    if (!jArgb || !jMask || env->GetArrayLength(jArgb) != count || env->GetArrayLength(jMask) != count) {
        fail(env, "Image and mask pixel counts do not match.");
        return nullptr;
    }
    const std::string model = jstringToString(env, jModelPath);
    const std::string prompt = jstringToString(env, jPrompt);
    const std::string negative = jstringToString(env, jNegative);
    if (model.empty() || prompt.empty()) {
        fail(env, "A model file and text prompt are required.");
        return nullptr;
    }
    if (steps < 1 || steps > 60 || strength <= 0.f || strength > 1.f) {
        fail(env, "Invalid diffusion settings.");
        return nullptr;
    }

    std::vector<jint> pixels(static_cast<size_t>(count));
    std::vector<jbyte> maskInput(static_cast<size_t>(count));
    env->GetIntArrayRegion(jArgb, 0, count, pixels.data());
    env->GetByteArrayRegion(jMask, 0, count, maskInput.data());
    if (env->ExceptionCheck()) return nullptr;

    std::vector<uint8_t> rgb(static_cast<size_t>(count) * 3);
    std::vector<uint8_t> mask(static_cast<size_t>(count));
    for (jsize i = 0; i < count; ++i) {
        auto color = static_cast<uint32_t>(pixels[i]);
        rgb[static_cast<size_t>(i)*3] = (color >> 16) & 255;
        rgb[static_cast<size_t>(i)*3+1] = (color >> 8) & 255;
        rgb[static_cast<size_t>(i)*3+2] = color & 255;
        mask[i] = static_cast<uint8_t>(maskInput[i]);
    }

    if (!cachedCtx || cachedModel != model) {
        releaseCachedContext();
        sd_ctx_params_t ctxParams;
        sd_ctx_params_init(&ctxParams);
        ctxParams.model_path = model.c_str();
        ctxParams.n_threads = 4;
        ctxParams.enable_mmap = true;
        ctxParams.flash_attn = true;
        cachedCtx = new_sd_ctx(&ctxParams);
        if (!cachedCtx) {
            fail(env, "Model loading failed. Check checkpoint compatibility and available RAM.");
            return nullptr;
        }
        cachedModel = model;
    }

    sd_img_gen_params_t params;
    sd_img_gen_params_init(&params);
    params.init_image = {static_cast<uint32_t>(width), static_cast<uint32_t>(height), 3, rgb.data()};
    params.mask_image = {static_cast<uint32_t>(width), static_cast<uint32_t>(height), 1, mask.data()};
    params.width = width;
    params.height = height;
    params.prompt = prompt.c_str();
    params.negative_prompt = negative.c_str();
    params.sample_params.sample_steps = steps;
    params.sample_params.guidance.txt_cfg = cfg;
    params.strength = strength;
    params.seed = static_cast<int64_t>(seed);
    params.batch_count = 1;

    sd_image_generation_result_t* result = nullptr;
    bool success = generate_image(cachedCtx, &params, &result);
    if (!success || !result || result->count < 1 || !result->items || !result->items[0].image.data) {
        if (result) free_sd_image_generation_result(result);
        fail(env, "Image generation failed. Inspect Android logcat for SD engine diagnostics.");
        return nullptr;
    }

    const sd_image_t& img = result->items[0].image;
    if (img.width != static_cast<uint32_t>(width) || img.height != static_cast<uint32_t>(height) || img.channel < 3) {
        free_sd_image_generation_result(result);
        fail(env, "Model returned unexpected dimensions or channel count.");
        return nullptr;
    }
    std::vector<jint> out(static_cast<size_t>(count));
    for (jsize i = 0; i < count; ++i) {
        const uint8_t* p = img.data + static_cast<size_t>(i) * img.channel;
        // Preserve every untouched source pixel exactly. Feathered brush edges blend naturally.
        const uint32_t alpha = mask[i];
        const uint32_t source = static_cast<uint32_t>(pixels[i]);
        const uint32_t r = (uint32_t(p[0]) * alpha + ((source >> 16) & 255u) * (255u - alpha) + 127u) / 255u;
        const uint32_t g = (uint32_t(p[1]) * alpha + ((source >> 8) & 255u) * (255u - alpha) + 127u) / 255u;
        const uint32_t b = (uint32_t(p[2]) * alpha + (source & 255u) * (255u - alpha) + 127u) / 255u;
        out[i] = static_cast<jint>(0xff000000u | (r << 16) | (g << 8) | b);
    }
    free_sd_image_generation_result(result);
    jintArray array = env->NewIntArray(count);
    if (array) env->SetIntArrayRegion(array, 0, count, out.data());
    return array;
}
