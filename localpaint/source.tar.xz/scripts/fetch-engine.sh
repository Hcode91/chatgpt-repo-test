#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p vendor
if [ ! -f vendor/stable-diffusion.cpp/CMakeLists.txt ]; then
  git clone --depth 1 --recurse-submodules https://github.com/leejet/stable-diffusion.cpp vendor/stable-diffusion.cpp
else
  git -C vendor/stable-diffusion.cpp submodule update --init --recursive
fi
