# CCI Extractor for Android

A native Android (26+) application for browsing and extracting the files inside **decrypted Nintendo 3DS CCI / NCSD** cartridge dumps. No system/root permissions, keys, or network access are required.

## Features

- Open an existing `.cci` / `.3ds` file using Android's system file picker.
- Inspect NCSD partitions and the RomFS / ExeFS file trees.
- Tap a file to extract only that file; extract the current folder or the entire archive.
- Select a destination folder using Android's system folder picker.
- Preserves original filenames and directories, writing to a new `CCI_Extract_YYYYMMDD_HHMMSS` folder.
- Streams large files in 128 KB chunks without loading the full CCI into RAM.
- Cancels an ongoing extraction; does **not** modify the original CCI.
- Supports archives where decrypted RomFS has an `IVFC` header. Detects unsupported/encrypted archives with an explanation.

## Current scope and limitations

- Only **unencrypted/decrypted** content is extracted. This tool doesn't provide keys or decrypt encrypted NCCH content. It will reject encrypted RomFS rather than write junk files.
- Supports standard NCSD/NCCH, ExeFS and IVFC RomFS level 3 layouts. Exotic image layouts may not parse.
- ExeFS `.code` is extracted as stored (it may still be compressed). This is a file extractor, **not** a texture decoder or a game mod writer.
- It works best with a locally stored, seekable file, rather than a cloud-only document provider.
- Android may interrupt long extractions if the process is killed; keep the app on-screen during extraction.
- Extractions are not resumable. For an interrupted run choose a new target folder and run again.
- The application does not bundle copyrighted games, firmware, or cryptographic keys.

## Build an APK using GitHub Actions

1. Upload this project to a GitHub repository (preserve `.github/workflows/android.yml`).
2. Open the **Actions** tab, select **Build Android APK**, then **Run workflow** (or push to `main`).
3. Download the `cci-extractor-debug-apk` artifact from the completed run.
4. Extract the downloaded artifact ZIP and install `app-debug.apk` on Android.

Or use Android Studio with JDK 17 and run **Build > Build APK(s)**. The GitHub Action uses Gradle 8.9 and Android Gradle Plugin 8.7.3.

## Quick test with Yumi's Odd Odyssey

1. Open the decrypted CCI in the app.
2. Browse `partition_0/romfs/system/`.
3. Tap `TitleLogo.btex`, select **Extract**, and choose a destination folder.
4. The original `TitleLogo.btex` will be copied into a dated folder. Compare it to your texture mod or edit a copy as needed.

## References

- [NCSD CCI format (3dbrew)](https://3dbrew.org/wiki/NCSD)
- [NCCH filesystem offsets (3dbrew)](https://3dbrew.org/wiki/NCCH)
- [IVFC RomFS metadata (3dbrew)](https://www.3dbrew.org/wiki/RomFS)
- [Android Storage Access Framework](https://developer.android.com/training/data-storage/shared/documents-files)

For personal backups and other content you are entitled to access. This repository supplies only generic parsing/extraction code.
